**Publix at Barrett Parkway**
================================

**Address:**
1635 Old Hwy 41 NE
Kennesaw, GA 30152

**Store Manager:**
Marie Sarr
770-426-5299

**Receipt Details**
-------------------

### Items Purchased:

*   Eggplant
    *   Quantity: 2.91 lb
    *   Price: $2.99/lb
    *   Total: $8.70 t F
*   Potatoes Russet
    *   Quantity: 1.67 lb
    *   Price: $0.99/lb
    *   Total: $1.65 t F
*   BH FRSH MZZ BALL
    *   Quantity: 5.39 t F
*   Onions Jumbo WHT
    *   Quantity: 1.09 lb
    *   Price: $1.99/lb
    *   Total: $2.17 t F
*   CHEEZ-IT S/S ORIGN
    *   Quantity: 1 @ 2 FOR $3.00
    *   Total: $1.50 t F